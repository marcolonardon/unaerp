# Sistema CRUD Acadêmico

Este é um sistema completo de CRUD (Create, Read, Update, Delete) para gerenciar entidades acadêmicas desenvolvido em PHP com MySQL.

## Estrutura do Sistema

O sistema gerencia as seguintes entidades:
- **Endereços**: Dados de localização
- **Cursos**: Cursos oferecidos pela instituição
- **Disciplinas**: Disciplinas com carga horária
- **Pessoas**: Dados pessoais básicos
- **Alunos**: Estudantes vinculados a cursos
- **Funcionários**: Colaboradores com dados de admissão e salário

## Configuração do Banco de Dados

### 1. Criar o Banco de Dados
Execute o script SQL fornecido no arquivo `database.sql` no seu MySQL:

```sql
-- Acesse o MySQL e execute:
mysql -u root -p
source database.sql
```

### 2. Configurar Conexão
O sistema está configurado para usar as seguintes credenciais (arquivo `Database.php`):
- **Servidor**: localhost
- **Usuário**: root
- **Senha**: (vazia)
- **Banco**: sistema_academico

Se suas credenciais forem diferentes, edite o arquivo `Database.php`.

### 3. Estrutura das Tabelas
O sistema criará automaticamente as seguintes tabelas:
- `enderecos`
- `cursos`
- `disciplinas`
- `pessoas`
- `alunos`
- `funcionarios`

## Como Usar

### Iniciando o Sistema
1. Certifique-se de que o servidor web (Apache/Nginx) e MySQL estão rodando
2. Acesse o arquivo `index.html` no seu navegador
3. Navegue através do menu para gerenciar cada entidade

### Funcionalidades Disponíveis

#### Para cada entidade você pode:
- **Criar**: Adicionar novos registros
- **Visualizar**: Listar todos os registros em tabelas
- **Editar**: Modificar registros existentes
- **Deletar**: Remover registros (com confirmação)

#### Relacionamentos:
- Pessoas podem ter endereços associados
- Alunos herdam de Pessoa e podem ter cursos
- Funcionários herdam de Pessoa e têm dados de admissão/salário

## Arquivos do Sistema

### Classes Modelo (Model)
- `Endereco.php` - Classe para endereços
- `Curso.php` - Classe para cursos
- `Disciplina.php` - Classe para disciplinas
- `Pessoa.php` - Classe base para pessoas
- `Aluno.php` - Classe para alunos (herda de Pessoa)
- `Funcionario.php` - Classe para funcionários (herda de Pessoa)

### Classes DAO (Data Access Object)
- `Database.php` - Gerenciamento de conexão
- `EnderecoDAO.php` - Operações CRUD para endereços
- `CursoDAO.php` - Operações CRUD para cursos
- `DisciplinaDAO.php` - Operações CRUD para disciplinas
- `PessoaDAO.php` - Operações CRUD para pessoas
- `AlunoDAO.php` - Operações CRUD para alunos
- `FuncionarioDAO.php` - Operações CRUD para funcionários

### Interface (Views)
- `index.html` - Menu principal
- `enderecos.php` - Gerenciar endereços
- `cursos.php` - Gerenciar cursos
- `disciplinas.php` - Gerenciar disciplinas
- `pessoas.php` - Gerenciar pessoas
- `alunos.php` - Gerenciar alunos
- `funcionarios.php` - Gerenciar funcionários

## Características Técnicas

### Segurança
- Uso de prepared statements para prevenir SQL injection
- Validação de dados no frontend
- Confirmação antes de deletar registros

### Arquitetura
- Padrão MVC básico
- Separação entre modelo, DAO e interface
- Uso de namespaces PHP
- Herança para Aluno e Funcionário (extends Pessoa)

### Frontend
- Interface responsiva com CSS Grid
- Formulários com validação HTML5
- Confirmações JavaScript para ações críticas
- Design limpo e funcional

## Requisitos do Sistema

- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Servidor web (Apache/Nginx)
- Extensões PHP: mysqli, PDO (opcional)

## Possíveis Melhorias Futuras

- Sistema de autenticação e autorização
- Paginação para listas grandes
- Filtros e busca avançada
- Validação mais robusta no backend
- API REST para integração com outros sistemas
- Interface mais sofisticada com frameworks JS
