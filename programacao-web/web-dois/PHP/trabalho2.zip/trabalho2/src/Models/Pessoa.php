<?php
namespace App;

class Pessoa {
    public $id;
    public $nome;
    public $telefone;
    public $celular;
    public $tipo;
    public $endereco_id;

    public $logradouro;
    public $complemento;
    public $cep;
    public $bairro;
    public $cidade;
    public $uf;

    public function __construct($data = []) {
        $this->id = $data['id'] ?? null;
        $this->nome = $data['nome'] ?? '';
        $this->telefone = $data['telefone'] ?? '';
        $this->celular = $data['celular'] ?? '';
        $this->tipo = $data['tipo'] ?? 'F';
        $this->endereco_id = $data['endereco_id'] ?? null;

        $this->logradouro = $data['logradouro'] ?? null;
        $this->complemento = $data['complemento'] ?? null;
        $this->cep = $data['cep'] ?? null;
        $this->bairro = $data['bairro'] ?? null;
        $this->cidade = $data['cidade'] ?? null;
        $this->uf = $data['uf'] ?? null;
    }
}
?>
