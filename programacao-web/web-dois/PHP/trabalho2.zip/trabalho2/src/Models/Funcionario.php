<?php
namespace App;

require_once __DIR__ . '/Pessoa.php';

class Funcionario extends Pessoa {
    public $funcionario_id;
    public $admissao;
    public $salario;

    public function __construct($data = []) {
        parent::__construct($data);
        $this->funcionario_id = $data['funcionario_id'] ?? null;
        $this->admissao = $data['admissao'] ?? null;
        $this->salario = $data['salario'] ?? 0;
    }
}
?>
