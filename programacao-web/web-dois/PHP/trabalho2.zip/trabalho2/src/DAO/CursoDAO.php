<?php
namespace App;

require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Curso.php';

class CursoDAO {
    private $db;
    private $conn;

    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }

    public function create(Curso $curso) {
        $sql = "INSERT INTO cursos (nome) VALUES (?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $curso->nome);

        if ($stmt->execute()) {
            $curso->id = $this->conn->insert_id;
            return true;
        }
        return false;
    }

    public function read($id) {
        $sql = "SELECT * FROM cursos WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            return new Curso($row);
        }
        return null;
    }

    public function readAll() {
        $sql = "SELECT * FROM cursos ORDER BY id DESC";
        $result = $this->conn->query($sql);
        $cursos = [];

        while ($row = $result->fetch_assoc()) {
            $cursos[] = new Curso($row);
        }
        return $cursos;
    }

    public function update(Curso $curso) {
        $sql = "UPDATE cursos SET nome=? WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $curso->nome, $curso->id);

        return $stmt->execute();
    }

    public function delete($id) {
        $sql = "DELETE FROM cursos WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);

        return $stmt->execute();
    }
}
?>
