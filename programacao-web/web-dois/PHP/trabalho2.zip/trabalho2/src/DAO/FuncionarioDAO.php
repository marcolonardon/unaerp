<?php
namespace App;

require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Funcionario.php';
require_once __DIR__ . '/PessoaDAO.php';

class FuncionarioDAO {
    private $db;
    private $conn;
    private $pessoaDAO;

    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
        $this->pessoaDAO = new PessoaDAO();
    }

    public function create(Funcionario $funcionario) {
        if (!$this->pessoaDAO->create($funcionario)) {
            return false;
        }

        $sql = "INSERT INTO funcionarios (pessoa_id, admissao, salario) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("isd", $funcionario->id, $funcionario->admissao, $funcionario->salario);

        return $stmt->execute();
    }

    public function read($id) {
        $sql = "SELECT f.id as funcionario_id, f.admissao, f.salario,
                       p.id, p.nome, p.telefone, p.celular, p.tipo, p.endereco_id,
                       e.logradouro, e.complemento, e.cep, e.bairro, e.cidade, e.uf
                FROM funcionarios f
                INNER JOIN pessoas p ON f.pessoa_id = p.id
                LEFT JOIN enderecos e ON p.endereco_id = e.id
                WHERE f.id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $data = $row;
            $data['id'] = $row['id'];
            return new Funcionario($data);
        }
        return null;
    }

    public function readAll() {
        $sql = "SELECT f.id as funcionario_id, f.admissao, f.salario,
                       p.id, p.nome, p.telefone, p.celular, p.tipo, p.endereco_id,
                       e.logradouro, e.complemento, e.cep, e.bairro, e.cidade, e.uf
                FROM funcionarios f
                INNER JOIN pessoas p ON f.pessoa_id = p.id
                LEFT JOIN enderecos e ON p.endereco_id = e.id
                ORDER BY f.id DESC";
        $result = $this->conn->query($sql);
        $funcionarios = [];

        while ($row = $result->fetch_assoc()) {
            $data = $row;
            $data['funcionario_id'] = $row['funcionario_id'];
            $funcionarios[] = new Funcionario($data);
        }
        return $funcionarios;
    }

    public function update(Funcionario $funcionario) {
        if (!$this->pessoaDAO->update($funcionario)) {
            return false;
        }

        $sql = "UPDATE funcionarios SET admissao=?, salario=? WHERE pessoa_id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sdi", $funcionario->admissao, $funcionario->salario, $funcionario->id);

        return $stmt->execute();
    }

    public function delete($funcionario_id) {
        $sql = "SELECT pessoa_id FROM funcionarios WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $funcionario_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $pessoa_id = $row['pessoa_id'];

            $sql = "DELETE FROM funcionarios WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $funcionario_id);
            $stmt->execute();

            return $this->pessoaDAO->delete($pessoa_id);
        }
        return false;
    }
}
?>
