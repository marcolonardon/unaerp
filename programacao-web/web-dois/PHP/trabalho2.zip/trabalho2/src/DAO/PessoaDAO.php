<?php
namespace App;

require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Pessoa.php';
require_once __DIR__ . '/../Models/Endereco.php';

class PessoaDAO {
    private $db;
    private $conn;

    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }

    public function create(Pessoa $pessoa) {
        if (empty($pessoa->logradouro) || empty($pessoa->cidade)) {
            return false;
        }

        $endereco_id = $this->createEndereco($pessoa);
        if (!$endereco_id) {
            return false;
        }

        $sql = "INSERT INTO pessoas (nome, telefone, celular, tipo, endereco_id) VALUES (?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssi", $pessoa->nome, $pessoa->telefone, $pessoa->celular, $pessoa->tipo, $endereco_id);

        if ($stmt->execute()) {
            $pessoa->id = $this->conn->insert_id;
            $pessoa->endereco_id = $endereco_id;
            return true;
        }
        return false;
    }

    public function read($id) {
        $sql = "SELECT p.*, e.logradouro, e.complemento, e.cep, e.bairro, e.cidade, e.uf
                FROM pessoas p
                LEFT JOIN enderecos e ON p.endereco_id = e.id
                WHERE p.id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            return new Pessoa($row);
        }
        return null;
    }

    public function readAll() {
        $sql = "SELECT p.*, e.logradouro, e.complemento, e.cep, e.bairro, e.cidade, e.uf
                FROM pessoas p
                LEFT JOIN enderecos e ON p.endereco_id = e.id
                ORDER BY p.id DESC";
        $result = $this->conn->query($sql);
        $pessoas = [];

        while ($row = $result->fetch_assoc()) {
            $pessoas[] = new Pessoa($row);
        }
        return $pessoas;
    }

    public function update(Pessoa $pessoa) {
        if (empty($pessoa->logradouro) || empty($pessoa->cidade)) {
            return false;
        }

        if ($pessoa->endereco_id) {
            $this->updateEndereco($pessoa);
        } else {
            $endereco_id = $this->createEndereco($pessoa);
            $pessoa->endereco_id = $endereco_id;
        }

        $sql = "UPDATE pessoas SET nome=?, telefone=?, celular=?, tipo=?, endereco_id=? WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssii", $pessoa->nome, $pessoa->telefone, $pessoa->celular, $pessoa->tipo, $pessoa->endereco_id, $pessoa->id);

        return $stmt->execute();
    }

    public function delete($id) {
        $pessoa = $this->read($id);

        $sql = "DELETE FROM pessoas WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);

        $result = $stmt->execute();

        if ($result && $pessoa && $pessoa->endereco_id) {
            $this->deleteEnderecoIfUnused($pessoa->endereco_id);
        }

        return $result;
    }

    private function createEndereco(Pessoa $pessoa) {
        $sql = "INSERT INTO enderecos (logradouro, complemento, cep, bairro, cidade, uf) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssss", $pessoa->logradouro, $pessoa->complemento, $pessoa->cep, $pessoa->bairro, $pessoa->cidade, $pessoa->uf);

        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        return false;
    }

    private function updateEndereco(Pessoa $pessoa) {
        $sql = "UPDATE enderecos SET logradouro=?, complemento=?, cep=?, bairro=?, cidade=?, uf=? WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssssi", $pessoa->logradouro, $pessoa->complemento, $pessoa->cep, $pessoa->bairro, $pessoa->cidade, $pessoa->uf, $pessoa->endereco_id);

        return $stmt->execute();
    }

    private function deleteEndereco($endereco_id) {
        $sql = "DELETE FROM enderecos WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $endereco_id);

        return $stmt->execute();
    }

    private function deleteEnderecoIfUnused($endereco_id) {
        $sql = "SELECT COUNT(*) as count FROM pessoas WHERE endereco_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $endereco_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row['count'] == 0) {
            $this->deleteEndereco($endereco_id);
        }
    }
}
?>