<?php
namespace App;

require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Aluno.php';
require_once __DIR__ . '/PessoaDAO.php';

class AlunoDAO {
    private $db;
    private $conn;
    private $pessoaDAO;

    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
        $this->pessoaDAO = new PessoaDAO();
    }

    public function create(Aluno $aluno) {
        if (!$this->pessoaDAO->create($aluno)) {
            return false;
        }

        $sql = "INSERT INTO alunos (pessoa_id, matricula, curso_id) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("isi", $aluno->id, $aluno->matricula, $aluno->curso_id);

        return $stmt->execute();
    }

    public function read($id) {
        $sql = "SELECT a.*, p.nome, p.telefone, p.celular, p.tipo, p.endereco_id,
                       c.nome as curso_nome,
                       e.logradouro, e.complemento, e.cep, e.bairro, e.cidade, e.uf
                FROM alunos a
                INNER JOIN pessoas p ON a.pessoa_id = p.id
                LEFT JOIN cursos c ON a.curso_id = c.id
                LEFT JOIN enderecos e ON p.endereco_id = e.id
                WHERE a.id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $data = $row;
            $data['id'] = $row['pessoa_id'];
            return new Aluno($data);
        }
        return null;
    }

    public function readAll() {
        $sql = "SELECT a.id as aluno_id, a.matricula, a.curso_id,
                       p.id, p.nome, p.telefone, p.celular, p.tipo, p.endereco_id,
                       c.nome as curso_nome,
                       e.logradouro, e.complemento, e.cep, e.bairro, e.cidade, e.uf
                FROM alunos a
                INNER JOIN pessoas p ON a.pessoa_id = p.id
                LEFT JOIN cursos c ON a.curso_id = c.id
                LEFT JOIN enderecos e ON p.endereco_id = e.id
                ORDER BY a.id DESC";
        $result = $this->conn->query($sql);
        $alunos = [];

        while ($row = $result->fetch_assoc()) {
            $data = $row;
            $data['aluno_id'] = $row['aluno_id'];
            $alunos[] = new Aluno($data);
        }
        return $alunos;
    }

    public function update(Aluno $aluno) {
        if (!$this->pessoaDAO->update($aluno)) {
            return false;
        }

        $sql = "UPDATE alunos SET matricula=?, curso_id=? WHERE pessoa_id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sii", $aluno->matricula, $aluno->curso_id, $aluno->id);

        return $stmt->execute();
    }

    public function delete($aluno_id) {
        $sql = "SELECT pessoa_id FROM alunos WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $aluno_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $pessoa_id = $row['pessoa_id'];

            $sql = "DELETE FROM alunos WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("i", $aluno_id);
            $stmt->execute();

            return $this->pessoaDAO->delete($pessoa_id);
        }
        return false;
    }
}
?>
