<?php
namespace App;

require_once __DIR__ . '/../../config/Database.php';
require_once __DIR__ . '/../Models/Disciplina.php';

class DisciplinaDAO {
    private $db;
    private $conn;

    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }

    public function create(Disciplina $disciplina) {
        $sql = "INSERT INTO disciplinas (nome, carga_horaria) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("si", $disciplina->nome, $disciplina->carga_horaria);

        if ($stmt->execute()) {
            $disciplina->id = $this->conn->insert_id;
            return true;
        }
        return false;
    }

    public function read($id) {
        $sql = "SELECT * FROM disciplinas WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            return new Disciplina($row);
        }
        return null;
    }

    public function readAll() {
        $sql = "SELECT * FROM disciplinas ORDER BY id DESC";
        $result = $this->conn->query($sql);
        $disciplinas = [];

        while ($row = $result->fetch_assoc()) {
            $disciplinas[] = new Disciplina($row);
        }
        return $disciplinas;
    }

    public function update(Disciplina $disciplina) {
        $sql = "UPDATE disciplinas SET nome=?, carga_horaria=? WHERE id=?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sii", $disciplina->nome, $disciplina->carga_horaria, $disciplina->id);

        return $stmt->execute();
    }

    public function delete($id) {
        $sql = "DELETE FROM disciplinas WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $id);

        return $stmt->execute();
    }
}
?>
