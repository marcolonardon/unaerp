<?php
require_once __DIR__ . '/../DAO/FuncionarioDAO.php';
use App\FuncionarioDAO;
use App\Funcionario;

$funcionarioDAO = new FuncionarioDAO();
$mensagem = '';

session_start();
if (isset($_SESSION['mensagem'])) {
    $mensagem = $_SESSION['mensagem'];
    unset($_SESSION['mensagem']);
}

if ($_POST) {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'criar':
            $funcionario = new Funcionario($_POST);
            if ($funcionarioDAO->create($funcionario)) {
                $_SESSION['mensagem'] = "Funcionário criado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao criar funcionário.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'atualizar':
            $funcionario = new Funcionario($_POST);
            if ($funcionarioDAO->update($funcionario)) {
                $_SESSION['mensagem'] = "Funcionário atualizado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao atualizar funcionário.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'deletar':
            if ($funcionarioDAO->delete($_POST['funcionario_id'])) {
                $_SESSION['mensagem'] = "Funcionário deletado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar funcionário.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;
    }
}

$funcionario_edit = null;
if (isset($_GET['edit'])) {
    $funcionario_edit = $funcionarioDAO->read($_GET['edit']);
}

$funcionarios = $funcionarioDAO->readAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Funcionários</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4; }
        .container { max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; margin-right: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 14px; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .mensagem { padding: 10px; margin: 10px 0; border-radius: 4px; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .form-row { display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 15px; }
        .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }
        .endereco-section { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .endereco-title { margin: 0 0 15px 0; color: #495057; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciar Funcionários</h1>
        <a href="../../public/index.html" class="btn btn-secondary">← Voltar ao Menu</a>

        <?php if ($mensagem): ?>
            <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>

        <h2><?= $funcionario_edit ? 'Editar' : 'Criar' ?> Funcionário</h2>
        <form method="POST">
            <input type="hidden" name="acao" value="<?= $funcionario_edit ? 'atualizar' : 'criar' ?>">
            <?php if ($funcionario_edit): ?>
                <input type="hidden" name="id" value="<?= $funcionario_edit->id ?>">
                <input type="hidden" name="funcionario_id" value="<?= $funcionario_edit->funcionario_id ?>">
                <input type="hidden" name="endereco_id" value="<?= $funcionario_edit->endereco_id ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>Nome:</label>
                <input type="text" name="nome" value="<?= $funcionario_edit->nome ?? '' ?>" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Telefone:</label>
                    <input type="text" name="telefone" value="<?= $funcionario_edit->telefone ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Celular:</label>
                    <input type="text" name="celular" value="<?= $funcionario_edit->celular ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Tipo:</label>
                    <select name="tipo" required>
                        <option value="F" <?= ($funcionario_edit && $funcionario_edit->tipo === 'F') ? 'selected' : '' ?>>Física</option>
                        <option value="J" <?= ($funcionario_edit && $funcionario_edit->tipo === 'J') ? 'selected' : '' ?>>Jurídica</option>
                    </select>
                </div>
            </div>

            <div class="form-row-2">
                <div class="form-group">
                    <label>Data de Admissão:</label>
                    <input type="date" name="admissao" value="<?= $funcionario_edit->admissao ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Salário:</label>
                    <input type="number" step="0.01" name="salario" value="<?= $funcionario_edit->salario ?? '' ?>" placeholder="0.00">
                </div>
            </div>

            <div class="endereco-section">
                <h3 class="endereco-title">Endereço</h3>

                <div class="form-group">
                    <label>Logradouro:</label>
                    <input type="text" name="logradouro" value="<?= $funcionario_edit->logradouro ?? '' ?>" placeholder="Ex: Rua das Flores, 123" required>
                </div>

                <div class="form-row-3">
                    <div class="form-group">
                        <label>Complemento:</label>
                        <input type="text" name="complemento" value="<?= $funcionario_edit->complemento ?? '' ?>" placeholder="Ex: Apto 45">
                    </div>
                    <div class="form-group">
                        <label>CEP:</label>
                        <input type="text" name="cep" value="<?= $funcionario_edit->cep ?? '' ?>" placeholder="Ex: 12345-678">
                    </div>
                    <div class="form-group">
                        <label>Bairro:</label>
                        <input type="text" name="bairro" value="<?= $funcionario_edit->bairro ?? '' ?>" placeholder="Ex: Centro">
                    </div>
                </div>

                <div class="form-row-2">
                    <div class="form-group">
                        <label>Cidade:</label>
                        <input type="text" name="cidade" value="<?= $funcionario_edit->cidade ?? '' ?>" placeholder="Ex: São Paulo" required>
                    </div>
                    <div class="form-group">
                        <label>UF:</label>
                        <select name="uf" required>
                            <option value="">Selecione...</option>
                            <option value="AC" <?= ($funcionario_edit && $funcionario_edit->uf === 'AC') ? 'selected' : '' ?>>AC</option>
                            <option value="AL" <?= ($funcionario_edit && $funcionario_edit->uf === 'AL') ? 'selected' : '' ?>>AL</option>
                            <option value="AP" <?= ($funcionario_edit && $funcionario_edit->uf === 'AP') ? 'selected' : '' ?>>AP</option>
                            <option value="AM" <?= ($funcionario_edit && $funcionario_edit->uf === 'AM') ? 'selected' : '' ?>>AM</option>
                            <option value="BA" <?= ($funcionario_edit && $funcionario_edit->uf === 'BA') ? 'selected' : '' ?>>BA</option>
                            <option value="CE" <?= ($funcionario_edit && $funcionario_edit->uf === 'CE') ? 'selected' : '' ?>>CE</option>
                            <option value="DF" <?= ($funcionario_edit && $funcionario_edit->uf === 'DF') ? 'selected' : '' ?>>DF</option>
                            <option value="ES" <?= ($funcionario_edit && $funcionario_edit->uf === 'ES') ? 'selected' : '' ?>>ES</option>
                            <option value="GO" <?= ($funcionario_edit && $funcionario_edit->uf === 'GO') ? 'selected' : '' ?>>GO</option>
                            <option value="MA" <?= ($funcionario_edit && $funcionario_edit->uf === 'MA') ? 'selected' : '' ?>>MA</option>
                            <option value="MT" <?= ($funcionario_edit && $funcionario_edit->uf === 'MT') ? 'selected' : '' ?>>MT</option>
                            <option value="MS" <?= ($funcionario_edit && $funcionario_edit->uf === 'MS') ? 'selected' : '' ?>>MS</option>
                            <option value="MG" <?= ($funcionario_edit && $funcionario_edit->uf === 'MG') ? 'selected' : '' ?>>MG</option>
                            <option value="PA" <?= ($funcionario_edit && $funcionario_edit->uf === 'PA') ? 'selected' : '' ?>>PA</option>
                            <option value="PB" <?= ($funcionario_edit && $funcionario_edit->uf === 'PB') ? 'selected' : '' ?>>PB</option>
                            <option value="PR" <?= ($funcionario_edit && $funcionario_edit->uf === 'PR') ? 'selected' : '' ?>>PR</option>
                            <option value="PE" <?= ($funcionario_edit && $funcionario_edit->uf === 'PE') ? 'selected' : '' ?>>PE</option>
                            <option value="PI" <?= ($funcionario_edit && $funcionario_edit->uf === 'PI') ? 'selected' : '' ?>>PI</option>
                            <option value="RJ" <?= ($funcionario_edit && $funcionario_edit->uf === 'RJ') ? 'selected' : '' ?>>RJ</option>
                            <option value="RN" <?= ($funcionario_edit && $funcionario_edit->uf === 'RN') ? 'selected' : '' ?>>RN</option>
                            <option value="RS" <?= ($funcionario_edit && $funcionario_edit->uf === 'RS') ? 'selected' : '' ?>>RS</option>
                            <option value="RO" <?= ($funcionario_edit && $funcionario_edit->uf === 'RO') ? 'selected' : '' ?>>RO</option>
                            <option value="RR" <?= ($funcionario_edit && $funcionario_edit->uf === 'RR') ? 'selected' : '' ?>>RR</option>
                            <option value="SC" <?= ($funcionario_edit && $funcionario_edit->uf === 'SC') ? 'selected' : '' ?>>SC</option>
                            <option value="SP" <?= ($funcionario_edit && $funcionario_edit->uf === 'SP') ? 'selected' : '' ?>>SP</option>
                            <option value="SE" <?= ($funcionario_edit && $funcionario_edit->uf === 'SE') ? 'selected' : '' ?>>SE</option>
                            <option value="TO" <?= ($funcionario_edit && $funcionario_edit->uf === 'TO') ? 'selected' : '' ?>>TO</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary"><?= $funcionario_edit ? 'Atualizar' : 'Criar' ?></button>
            <?php if ($funcionario_edit): ?>
                <a href="funcionarios.php" class="btn btn-secondary">Cancelar</a>
            <?php endif; ?>
        </form>

        <h2>Lista de Funcionários</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Celular</th>
                    <th>Tipo</th>
                    <th>Admissão</th>
                    <th>Salário</th>
                    <th>Endereço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($funcionarios as $funcionario): ?>
                <tr>
                    <td><?= $funcionario->funcionario_id ?></td>
                    <td><?= htmlspecialchars($funcionario->nome) ?></td>
                    <td><?= htmlspecialchars($funcionario->telefone) ?></td>
                    <td><?= htmlspecialchars($funcionario->celular) ?></td>
                    <td><?= $funcionario->tipo === 'F' ? 'Física' : 'Jurídica' ?></td>
                    <td><?= $funcionario->admissao ? date('d/m/Y', strtotime($funcionario->admissao)) : 'Não informado' ?></td>
                    <td>R$ <?= number_format($funcionario->salario, 2, ',', '.') ?></td>
                    <td>
                        <?php if ($funcionario->logradouro): ?>
                            <?= htmlspecialchars($funcionario->logradouro . ', ' . $funcionario->bairro . ' - ' . $funcionario->cidade . '/' . $funcionario->uf) ?>
                        <?php else: ?>
                            Não informado
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?edit=<?= $funcionario->funcionario_id ?>" class="btn btn-secondary">Editar</a>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Confirma a exclusão?')">
                            <input type="hidden" name="acao" value="deletar">
                            <input type="hidden" name="funcionario_id" value="<?= $funcionario->funcionario_id ?>">
                            <button type="submit" class="btn btn-danger">Deletar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>