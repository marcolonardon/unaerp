<?php
require_once __DIR__ . '/../DAO/PessoaDAO.php';
use App\PessoaDAO;
use App\Pessoa;

$pessoaDAO = new PessoaDAO();
$mensagem = '';

session_start();
if (isset($_SESSION['mensagem'])) {
    $mensagem = $_SESSION['mensagem'];
    unset($_SESSION['mensagem']);
}

if ($_POST) {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'criar':
            $pessoa = new Pessoa($_POST);
            if ($pessoaDAO->create($pessoa)) {
                $_SESSION['mensagem'] = "Pessoa criada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao criar pessoa.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'atualizar':
            $pessoa = new Pessoa($_POST);
            if ($pessoaDAO->update($pessoa)) {
                $_SESSION['mensagem'] = "Pessoa atualizada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao atualizar pessoa.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'deletar':
            if ($pessoaDAO->delete($_POST['id'])) {
                $_SESSION['mensagem'] = "Pessoa deletada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar pessoa.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;
    }
}

$pessoa_edit = null;
if (isset($_GET['edit'])) {
    $pessoa_edit = $pessoaDAO->read($_GET['edit']);
}

$pessoas = $pessoaDAO->readAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Pessoas</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; margin-right: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .mensagem { padding: 10px; margin: 10px 0; border-radius: 4px; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }
        .endereco-section { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .endereco-title { margin: 0 0 15px 0; color: #495057; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciar Pessoas</h1>
        <a href="../../public/index.html" class="btn btn-secondary">← Voltar ao Menu</a>

        <?php if ($mensagem): ?>
            <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>

        <h2><?= $pessoa_edit ? 'Editar' : 'Criar' ?> Pessoa</h2>
        <form method="POST">
            <input type="hidden" name="acao" value="<?= $pessoa_edit ? 'atualizar' : 'criar' ?>">
            <?php if ($pessoa_edit): ?>
                <input type="hidden" name="id" value="<?= $pessoa_edit->id ?>">
                <input type="hidden" name="endereco_id" value="<?= $pessoa_edit->endereco_id ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>Nome:</label>
                <input type="text" name="nome" value="<?= $pessoa_edit->nome ?? '' ?>" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Telefone:</label>
                    <input type="text" name="telefone" value="<?= $pessoa_edit->telefone ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Celular:</label>
                    <input type="text" name="celular" value="<?= $pessoa_edit->celular ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Tipo:</label>
                    <select name="tipo" required>
                        <option value="F" <?= ($pessoa_edit && $pessoa_edit->tipo === 'F') ? 'selected' : '' ?>>Física</option>
                        <option value="J" <?= ($pessoa_edit && $pessoa_edit->tipo === 'J') ? 'selected' : '' ?>>Jurídica</option>
                    </select>
                </div>
            </div>

            <div class="endereco-section">
                <h3 class="endereco-title">Endereço</h3>

                <div class="form-group">
                    <label>Logradouro:</label>
                    <input type="text" name="logradouro" value="<?= $pessoa_edit->logradouro ?? '' ?>" placeholder="Ex: Rua das Flores, 123" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Complemento:</label>
                        <input type="text" name="complemento" value="<?= $pessoa_edit->complemento ?? '' ?>" placeholder="Ex: Apto 45">
                    </div>
                    <div class="form-group">
                        <label>CEP:</label>
                        <input type="text" name="cep" value="<?= $pessoa_edit->cep ?? '' ?>" placeholder="Ex: 12345-678">
                    </div>
                    <div class="form-group">
                        <label>Bairro:</label>
                        <input type="text" name="bairro" value="<?= $pessoa_edit->bairro ?? '' ?>" placeholder="Ex: Centro">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Cidade:</label>
                        <input type="text" name="cidade" value="<?= $pessoa_edit->cidade ?? '' ?>" placeholder="Ex: São Paulo" required>
                    </div>
                    <div class="form-group">
                        <label>UF:</label>
                        <select name="uf" required>
                            <option value="">Selecione...</option>
                            <option value="AC" <?= ($pessoa_edit && $pessoa_edit->uf === 'AC') ? 'selected' : '' ?>>AC</option>
                            <option value="AL" <?= ($pessoa_edit && $pessoa_edit->uf === 'AL') ? 'selected' : '' ?>>AL</option>
                            <option value="AP" <?= ($pessoa_edit && $pessoa_edit->uf === 'AP') ? 'selected' : '' ?>>AP</option>
                            <option value="AM" <?= ($pessoa_edit && $pessoa_edit->uf === 'AM') ? 'selected' : '' ?>>AM</option>
                            <option value="BA" <?= ($pessoa_edit && $pessoa_edit->uf === 'BA') ? 'selected' : '' ?>>BA</option>
                            <option value="CE" <?= ($pessoa_edit && $pessoa_edit->uf === 'CE') ? 'selected' : '' ?>>CE</option>
                            <option value="DF" <?= ($pessoa_edit && $pessoa_edit->uf === 'DF') ? 'selected' : '' ?>>DF</option>
                            <option value="ES" <?= ($pessoa_edit && $pessoa_edit->uf === 'ES') ? 'selected' : '' ?>>ES</option>
                            <option value="GO" <?= ($pessoa_edit && $pessoa_edit->uf === 'GO') ? 'selected' : '' ?>>GO</option>
                            <option value="MA" <?= ($pessoa_edit && $pessoa_edit->uf === 'MA') ? 'selected' : '' ?>>MA</option>
                            <option value="MT" <?= ($pessoa_edit && $pessoa_edit->uf === 'MT') ? 'selected' : '' ?>>MT</option>
                            <option value="MS" <?= ($pessoa_edit && $pessoa_edit->uf === 'MS') ? 'selected' : '' ?>>MS</option>
                            <option value="MG" <?= ($pessoa_edit && $pessoa_edit->uf === 'MG') ? 'selected' : '' ?>>MG</option>
                            <option value="PA" <?= ($pessoa_edit && $pessoa_edit->uf === 'PA') ? 'selected' : '' ?>>PA</option>
                            <option value="PB" <?= ($pessoa_edit && $pessoa_edit->uf === 'PB') ? 'selected' : '' ?>>PB</option>
                            <option value="PR" <?= ($pessoa_edit && $pessoa_edit->uf === 'PR') ? 'selected' : '' ?>>PR</option>
                            <option value="PE" <?= ($pessoa_edit && $pessoa_edit->uf === 'PE') ? 'selected' : '' ?>>PE</option>
                            <option value="PI" <?= ($pessoa_edit && $pessoa_edit->uf === 'PI') ? 'selected' : '' ?>>PI</option>
                            <option value="RJ" <?= ($pessoa_edit && $pessoa_edit->uf === 'RJ') ? 'selected' : '' ?>>RJ</option>
                            <option value="RN" <?= ($pessoa_edit && $pessoa_edit->uf === 'RN') ? 'selected' : '' ?>>RN</option>
                            <option value="RS" <?= ($pessoa_edit && $pessoa_edit->uf === 'RS') ? 'selected' : '' ?>>RS</option>
                            <option value="RO" <?= ($pessoa_edit && $pessoa_edit->uf === 'RO') ? 'selected' : '' ?>>RO</option>
                            <option value="RR" <?= ($pessoa_edit && $pessoa_edit->uf === 'RR') ? 'selected' : '' ?>>RR</option>
                            <option value="SC" <?= ($pessoa_edit && $pessoa_edit->uf === 'SC') ? 'selected' : '' ?>>SC</option>
                            <option value="SP" <?= ($pessoa_edit && $pessoa_edit->uf === 'SP') ? 'selected' : '' ?>>SP</option>
                            <option value="SE" <?= ($pessoa_edit && $pessoa_edit->uf === 'SE') ? 'selected' : '' ?>>SE</option>
                            <option value="TO" <?= ($pessoa_edit && $pessoa_edit->uf === 'TO') ? 'selected' : '' ?>>TO</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary"><?= $pessoa_edit ? 'Atualizar' : 'Criar' ?></button>
            <?php if ($pessoa_edit): ?>
                <a href="pessoas.php" class="btn btn-secondary">Cancelar</a>
            <?php endif; ?>
        </form>

        <h2>Lista de Pessoas</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Celular</th>
                    <th>Tipo</th>
                    <th>Endereço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pessoas as $pessoa): ?>
                <tr>
                    <td><?= $pessoa->id ?></td>
                    <td><?= htmlspecialchars($pessoa->nome) ?></td>
                    <td><?= htmlspecialchars($pessoa->telefone) ?></td>
                    <td><?= htmlspecialchars($pessoa->celular) ?></td>
                    <td><?= $pessoa->tipo === 'F' ? 'Física' : 'Jurídica' ?></td>
                    <td>
                        <?php if ($pessoa->logradouro): ?>
                            <?= htmlspecialchars($pessoa->logradouro . ', ' . $pessoa->bairro . ' - ' . $pessoa->cidade . '/' . $pessoa->uf) ?>
                        <?php else: ?>
                            Não informado
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?edit=<?= $pessoa->id ?>" class="btn btn-secondary">Editar</a>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Confirma a exclusão?')">
                            <input type="hidden" name="acao" value="deletar">
                            <input type="hidden" name="id" value="<?= $pessoa->id ?>">
                            <button type="submit" class="btn btn-danger">Deletar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
