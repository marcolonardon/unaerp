<?php
require_once __DIR__ . '/../DAO/DisciplinaDAO.php';
use App\DisciplinaDAO;
use App\Disciplina;

$disciplinaDAO = new DisciplinaDAO();
$mensagem = '';

session_start();
if (isset($_SESSION['mensagem'])) {
    $mensagem = $_SESSION['mensagem'];
    unset($_SESSION['mensagem']);
}

if ($_POST) {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'criar':
            $disciplina = new Disciplina($_POST);
            if ($disciplinaDAO->create($disciplina)) {
                $_SESSION['mensagem'] = "Disciplina criada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao criar disciplina.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'atualizar':
            $disciplina = new Disciplina($_POST);
            if ($disciplinaDAO->update($disciplina)) {
                $_SESSION['mensagem'] = "Disciplina atualizada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao atualizar disciplina.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'deletar':
            if ($disciplinaDAO->delete($_POST['id'])) {
                $_SESSION['mensagem'] = "Disciplina deletada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar disciplina.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;
    }
}

$disciplina_edit = null;
if (isset($_GET['edit'])) {
    $disciplina_edit = $disciplinaDAO->read($_GET['edit']);
}

$disciplinas = $disciplinaDAO->readAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Disciplinas</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: #007bff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .mensagem { padding: 10px; margin: 10px 0; border-radius: 4px; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .form-row { display: grid; grid-template-columns: 2fr 1fr; gap: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciar Disciplinas</h1>
        <a href="../../public/index.html" class="btn btn-secondary">← Voltar ao Menu</a>

        <?php if ($mensagem): ?>
            <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>

        <h2><?= $disciplina_edit ? 'Editar' : 'Criar' ?> Disciplina</h2>
        <form method="POST">
            <input type="hidden" name="acao" value="<?= $disciplina_edit ? 'atualizar' : 'criar' ?>">
            <?php if ($disciplina_edit): ?>
                <input type="hidden" name="id" value="<?= $disciplina_edit->id ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="form-group">
                    <label>Nome da Disciplina:</label>
                    <input type="text" name="nome" value="<?= $disciplina_edit->nome ?? '' ?>" required>
                </div>
                <div class="form-group">
                    <label>Carga Horária:</label>
                    <input type="number" name="carga_horaria" value="<?= $disciplina_edit->carga_horaria ?? '' ?>" min="0" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary"><?= $disciplina_edit ? 'Atualizar' : 'Criar' ?></button>
            <?php if ($disciplina_edit): ?>
                <a href="disciplinas.php" class="btn btn-secondary">Cancelar</a>
            <?php endif; ?>
        </form>

        <h2>Lista de Disciplinas</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Carga Horária</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($disciplinas as $disciplina): ?>
                <tr>
                    <td><?= $disciplina->id ?></td>
                    <td><?= htmlspecialchars($disciplina->nome) ?></td>
                    <td><?= $disciplina->carga_horaria ?>h</td>
                    <td>
                        <a href="?edit=<?= $disciplina->id ?>" class="btn btn-secondary">Editar</a>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Confirma a exclusão?')">
                            <input type="hidden" name="acao" value="deletar">
                            <input type="hidden" name="id" value="<?= $disciplina->id ?>">
                            <button type="submit" class="btn btn-danger">Deletar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
