<?php
require_once __DIR__ . '/../DAO/AlunoDAO.php';
require_once __DIR__ . '/../DAO/CursoDAO.php';
use App\AlunoDAO;
use App\Aluno;
use App\CursoDAO;

$alunoDAO = new AlunoDAO();
$cursoDAO = new CursoDAO();
$mensagem = '';

session_start();
if (isset($_SESSION['mensagem'])) {
    $mensagem = $_SESSION['mensagem'];
    unset($_SESSION['mensagem']);
}

if ($_POST) {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'criar':
            $aluno = new Aluno($_POST);
            if ($alunoDAO->create($aluno)) {
                $_SESSION['mensagem'] = "Aluno criado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao criar aluno.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'atualizar':
            $aluno = new Aluno($_POST);
            if ($alunoDAO->update($aluno)) {
                $_SESSION['mensagem'] = "Aluno atualizado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao atualizar aluno.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'deletar':
            if ($alunoDAO->delete($_POST['aluno_id'])) {
                $_SESSION['mensagem'] = "Aluno deletado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar aluno.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;
    }
}

$aluno_edit = null;
if (isset($_GET['edit'])) {
    $aluno_edit = $alunoDAO->read($_GET['edit']);
}

$alunos = $alunoDAO->readAll();
$cursos = $cursoDAO->readAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Alunos</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4; }
        .container { max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; margin-right: 5px; }
        .btn-primary { background: #007bff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 14px; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .mensagem { padding: 10px; margin: 10px 0; border-radius: 4px; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .form-row { display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 15px; }
        .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }
        .endereco-section { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .endereco-title { margin: 0 0 15px 0; color: #495057; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciar Alunos</h1>
        <a href="../../public/index.html" class="btn btn-secondary">← Voltar ao Menu</a>

        <?php if ($mensagem): ?>
            <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>

        <h2><?= $aluno_edit ? 'Editar' : 'Criar' ?> Aluno</h2>
        <form method="POST">
            <input type="hidden" name="acao" value="<?= $aluno_edit ? 'atualizar' : 'criar' ?>">
            <?php if ($aluno_edit): ?>
                <input type="hidden" name="id" value="<?= $aluno_edit->id ?>">
                <input type="hidden" name="aluno_id" value="<?= $aluno_edit->aluno_id ?>">
                <input type="hidden" name="endereco_id" value="<?= $aluno_edit->endereco_id ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>Nome:</label>
                <input type="text" name="nome" value="<?= $aluno_edit->nome ?? '' ?>" required>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label>Matrícula:</label>
                    <input type="text" name="matricula" value="<?= $aluno_edit->matricula ?? '' ?>" required>
                </div>
                <div class="form-group">
                    <label>Telefone:</label>
                    <input type="text" name="telefone" value="<?= $aluno_edit->telefone ?? '' ?>">
                </div>
                <div class="form-group">
                    <label>Celular:</label>
                    <input type="text" name="celular" value="<?= $aluno_edit->celular ?? '' ?>">
                </div>
            </div>

            <div class="form-row-2">
                <div class="form-group">
                    <label>Tipo:</label>
                    <select name="tipo" required>
                        <option value="F" <?= ($aluno_edit && $aluno_edit->tipo === 'F') ? 'selected' : '' ?>>Física</option>
                        <option value="J" <?= ($aluno_edit && $aluno_edit->tipo === 'J') ? 'selected' : '' ?>>Jurídica</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Curso:</label>
                    <select name="curso_id">
                        <option value="">Selecione um curso (opcional)</option>
                        <?php foreach ($cursos as $curso): ?>
                            <option value="<?= $curso->id ?>"
                                    <?= ($aluno_edit && $aluno_edit->curso_id == $curso->id) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($curso->nome) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="endereco-section">
                <h3 class="endereco-title">Endereço</h3>

                <div class="form-group">
                    <label>Logradouro:</label>
                    <input type="text" name="logradouro" value="<?= $aluno_edit->logradouro ?? '' ?>" placeholder="Ex: Rua das Flores, 123" required>
                </div>

                <div class="form-row-3">
                    <div class="form-group">
                        <label>Complemento:</label>
                        <input type="text" name="complemento" value="<?= $aluno_edit->complemento ?? '' ?>" placeholder="Ex: Apto 45">
                    </div>
                    <div class="form-group">
                        <label>CEP:</label>
                        <input type="text" name="cep" value="<?= $aluno_edit->cep ?? '' ?>" placeholder="Ex: 12345-678">
                    </div>
                    <div class="form-group">
                        <label>Bairro:</label>
                        <input type="text" name="bairro" value="<?= $aluno_edit->bairro ?? '' ?>" placeholder="Ex: Centro">
                    </div>
                </div>

                <div class="form-row-2">
                    <div class="form-group">
                        <label>Cidade:</label>
                        <input type="text" name="cidade" value="<?= $aluno_edit->cidade ?? '' ?>" placeholder="Ex: São Paulo" required>
                    </div>
                    <div class="form-group">
                        <label>UF:</label>
                        <select name="uf" required>
                            <option value="">Selecione...</option>
                            <option value="AC" <?= ($aluno_edit && $aluno_edit->uf === 'AC') ? 'selected' : '' ?>>AC</option>
                            <option value="AL" <?= ($aluno_edit && $aluno_edit->uf === 'AL') ? 'selected' : '' ?>>AL</option>
                            <option value="AP" <?= ($aluno_edit && $aluno_edit->uf === 'AP') ? 'selected' : '' ?>>AP</option>
                            <option value="AM" <?= ($aluno_edit && $aluno_edit->uf === 'AM') ? 'selected' : '' ?>>AM</option>
                            <option value="BA" <?= ($aluno_edit && $aluno_edit->uf === 'BA') ? 'selected' : '' ?>>BA</option>
                            <option value="CE" <?= ($aluno_edit && $aluno_edit->uf === 'CE') ? 'selected' : '' ?>>CE</option>
                            <option value="DF" <?= ($aluno_edit && $aluno_edit->uf === 'DF') ? 'selected' : '' ?>>DF</option>
                            <option value="ES" <?= ($aluno_edit && $aluno_edit->uf === 'ES') ? 'selected' : '' ?>>ES</option>
                            <option value="GO" <?= ($aluno_edit && $aluno_edit->uf === 'GO') ? 'selected' : '' ?>>GO</option>
                            <option value="MA" <?= ($aluno_edit && $aluno_edit->uf === 'MA') ? 'selected' : '' ?>>MA</option>
                            <option value="MT" <?= ($aluno_edit && $aluno_edit->uf === 'MT') ? 'selected' : '' ?>>MT</option>
                            <option value="MS" <?= ($aluno_edit && $aluno_edit->uf === 'MS') ? 'selected' : '' ?>>MS</option>
                            <option value="MG" <?= ($aluno_edit && $aluno_edit->uf === 'MG') ? 'selected' : '' ?>>MG</option>
                            <option value="PA" <?= ($aluno_edit && $aluno_edit->uf === 'PA') ? 'selected' : '' ?>>PA</option>
                            <option value="PB" <?= ($aluno_edit && $aluno_edit->uf === 'PB') ? 'selected' : '' ?>>PB</option>
                            <option value="PR" <?= ($aluno_edit && $aluno_edit->uf === 'PR') ? 'selected' : '' ?>>PR</option>
                            <option value="PE" <?= ($aluno_edit && $aluno_edit->uf === 'PE') ? 'selected' : '' ?>>PE</option>
                            <option value="PI" <?= ($aluno_edit && $aluno_edit->uf === 'PI') ? 'selected' : '' ?>>PI</option>
                            <option value="RJ" <?= ($aluno_edit && $aluno_edit->uf === 'RJ') ? 'selected' : '' ?>>RJ</option>
                            <option value="RN" <?= ($aluno_edit && $aluno_edit->uf === 'RN') ? 'selected' : '' ?>>RN</option>
                            <option value="RS" <?= ($aluno_edit && $aluno_edit->uf === 'RS') ? 'selected' : '' ?>>RS</option>
                            <option value="RO" <?= ($aluno_edit && $aluno_edit->uf === 'RO') ? 'selected' : '' ?>>RO</option>
                            <option value="RR" <?= ($aluno_edit && $aluno_edit->uf === 'RR') ? 'selected' : '' ?>>RR</option>
                            <option value="SC" <?= ($aluno_edit && $aluno_edit->uf === 'SC') ? 'selected' : '' ?>>SC</option>
                            <option value="SP" <?= ($aluno_edit && $aluno_edit->uf === 'SP') ? 'selected' : '' ?>>SP</option>
                            <option value="SE" <?= ($aluno_edit && $aluno_edit->uf === 'SE') ? 'selected' : '' ?>>SE</option>
                            <option value="TO" <?= ($aluno_edit && $aluno_edit->uf === 'TO') ? 'selected' : '' ?>>TO</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary"><?= $aluno_edit ? 'Atualizar' : 'Criar' ?></button>
            <?php if ($aluno_edit): ?>
                <a href="alunos.php" class="btn btn-secondary">Cancelar</a>
            <?php endif; ?>
        </form>

        <h2>Lista de Alunos</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Matrícula</th>
                    <th>Telefone</th>
                    <th>Celular</th>
                    <th>Tipo</th>
                    <th>Curso</th>
                    <th>Endereço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alunos as $aluno): ?>
                <tr>
                    <td><?= $aluno->aluno_id ?></td>
                    <td><?= htmlspecialchars($aluno->nome) ?></td>
                    <td><?= htmlspecialchars($aluno->matricula) ?></td>
                    <td><?= htmlspecialchars($aluno->telefone) ?></td>
                    <td><?= htmlspecialchars($aluno->celular) ?></td>
                    <td><?= $aluno->tipo === 'F' ? 'Física' : 'Jurídica' ?></td>
                    <td><?= htmlspecialchars($aluno->curso_nome ?? 'Não informado') ?></td>
                    <td>
                        <?php if ($aluno->logradouro): ?>
                            <?= htmlspecialchars($aluno->logradouro . ', ' . $aluno->bairro . ' - ' . $aluno->cidade . '/' . $aluno->uf) ?>
                        <?php else: ?>
                            Não informado
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="?edit=<?= $aluno->aluno_id ?>" class="btn btn-secondary">Editar</a>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Confirma a exclusão?')">
                            <input type="hidden" name="acao" value="deletar">
                            <input type="hidden" name="aluno_id" value="<?= $aluno->aluno_id ?>">
                            <button type="submit" class="btn btn-danger">Deletar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
