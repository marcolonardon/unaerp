<?php
require_once __DIR__ . '/../DAO/CursoDAO.php';
use App\CursoDAO;
use App\Curso;

$cursoDAO = new CursoDAO();
$mensagem = '';

session_start();
if (isset($_SESSION['mensagem'])) {
    $mensagem = $_SESSION['mensagem'];
    unset($_SESSION['mensagem']);
}

if ($_POST) {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'criar':
            $curso = new Curso($_POST);
            if ($cursoDAO->create($curso)) {
                $_SESSION['mensagem'] = "Curso criado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao criar curso.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'atualizar':
            $curso = new Curso($_POST);
            if ($cursoDAO->update($curso)) {
                $_SESSION['mensagem'] = "Curso atualizado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao atualizar curso.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;

        case 'deletar':
            if ($cursoDAO->delete($_POST['id'])) {
                $_SESSION['mensagem'] = "Curso deletado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar curso.";
            }
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
            break;
    }
}

$curso_edit = null;
if (isset($_GET['edit'])) {
    $curso_edit = $cursoDAO->read($_GET['edit']);
}

$cursos = $cursoDAO->readAll();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Cursos</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select, textarea { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: #007bff; color: white; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn:hover { opacity: 0.8; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f8f9fa; }
        .mensagem { padding: 10px; margin: 10px 0; border-radius: 4px; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gerenciar Cursos</h1>
        <a href="../../public/index.html" class="btn btn-secondary">← Voltar ao Menu</a>

        <?php if ($mensagem): ?>
            <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
        <?php endif; ?>

        <h2><?= $curso_edit ? 'Editar' : 'Criar' ?> Curso</h2>
        <form method="POST">
            <input type="hidden" name="acao" value="<?= $curso_edit ? 'atualizar' : 'criar' ?>">
            <?php if ($curso_edit): ?>
                <input type="hidden" name="id" value="<?= $curso_edit->id ?>">
            <?php endif; ?>

            <div class="form-group">
                <label>Nome do Curso:</label>
                <input type="text" name="nome" value="<?= $curso_edit->nome ?? '' ?>" required>
            </div>

            <button type="submit" class="btn btn-primary"><?= $curso_edit ? 'Atualizar' : 'Criar' ?></button>
            <?php if ($curso_edit): ?>
                <a href="cursos.php" class="btn btn-secondary">Cancelar</a>
            <?php endif; ?>
        </form>

        <h2>Lista de Cursos</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cursos as $curso): ?>
                <tr>
                    <td><?= $curso->id ?></td>
                    <td><?= htmlspecialchars($curso->nome) ?></td>
                    <td>
                        <a href="?edit=<?= $curso->id ?>" class="btn btn-secondary">Editar</a>
                        <form method="POST" style="display: inline;" onsubmit="return confirm('Confirma a exclusão?')">
                            <input type="hidden" name="acao" value="deletar">
                            <input type="hidden" name="id" value="<?= $curso->id ?>">
                            <button type="submit" class="btn btn-danger">Deletar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
