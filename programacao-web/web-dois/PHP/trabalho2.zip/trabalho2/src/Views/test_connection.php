<?php
require_once __DIR__ . '/../../config/Database.php';
use App\Database;

echo "<h2>Teste de Conexão - Sistema CRUD Acadêmico</h2>";

try {
    $db = new Database();
    $conn = $db->getConnection();

    echo "<p style='color: green;'>✓ Conexão com o banco de dados estabelecida com sucesso!</p>";

    $tabelas = ['enderecos', 'cursos', 'disciplinas', 'pessoas', 'alunos', 'funcionarios'];

    echo "<h3>Verificando tabelas:</h3>";
    foreach ($tabelas as $tabela) {
        $result = $conn->query("SHOW TABLES LIKE '$tabela'");
        if ($result->num_rows > 0) {
            echo "<p style='color: green;'>✓ Tabela '$tabela' existe</p>";
        } else {
            echo "<p style='color: red;'>✗ Tabela '$tabela' não encontrada</p>";
        }
    }

    echo "<h3>Informações do banco:</h3>";
    $result = $conn->query("SELECT DATABASE() as db_name");
    $row = $result->fetch_assoc();
    echo "<p>Banco de dados atual: <strong>" . $row['db_name'] . "</strong></p>";

    $db->close();

} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Erro na conexão: " . $e->getMessage() . "</p>";
    echo "<p>Verifique se:</p>";
    echo "<ul>";
    echo "<li>O MySQL está rodando</li>";
    echo "<li>O banco 'sistema_academico' foi criado</li>";
    echo "<li>As credenciais estão corretas</li>";
    echo "</ul>";
}
?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h2 { color: #333; }
h3 { color: #666; margin-top: 20px; }
p { margin: 5px 0; }
</style>
